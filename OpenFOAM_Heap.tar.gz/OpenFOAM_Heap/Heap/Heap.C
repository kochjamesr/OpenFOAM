/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011-2013 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "Heap.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

// * * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * //

// * * * * * * * * * * * * *  Heap-Sorting Functions * * * * * * * * * * * * //

template<class T>
void Foam::Heap<T>::flipNodeCloserToRoot
(
    const label& NID
)
{
    // Cant heap toward root if at root.
    const label parentNID(getParentNID(NID));

    if (!softAccessPass(parentNID)) {return;}

    // If the curr node to the root than its parent node, heap toward root.
    if (nodeIsCloserToRoot(NID, parentNID))
    {
        exchangeNodes(NID, parentNID);
        flipNodeCloserToRoot(parentNID);
    }
}



template<class T>
void Foam::Heap<T>::flipNodeAwayFromRoot
(
    const label& NID
)
{
    // Can''t heap away from root if at tip.
    const label lChildNID(getLChildNID(NID));

    if (!softAccessPass(lChildNID)) {return;}

    const label rChildNID(getRChildNID(NID));

    // If both children exist, check which, if any, are further from the root
    // than the current node, heap it away from root.
    if (softAccessPass(rChildNID))
    {
        // Left child node is better than right.
        if (nodeIsCloserToRoot(lChildNID, rChildNID))
        {
            // Left child is better than current.
            if (nodeIsCloserToRoot(lChildNID, NID))
            {
                exchangeNodes(NID, lChildNID);
                flipNodeAwayFromRoot(lChildNID);
            }
        }
        // Right child is better than current.
        else if (nodeIsCloserToRoot(rChildNID, NID))
        {
            exchangeNodes(NID, rChildNID);
            flipNodeAwayFromRoot(rChildNID);
        }
    }
    // Only left child exists and is better than current.
    else if (nodeIsCloserToRoot(lChildNID, NID))
    {
        exchangeNodes(NID, lChildNID);
        flipNodeAwayFromRoot(lChildNID);
    }
}



template<class T>
void Foam::Heap<T>::heapSortAllNodes
()
{
    for (label NID=(size()-1); NID>=ROOTNID; NID--)
    {flipNodeAwayFromRoot(NID);}
}

// * * * * * * * * * * * *  Initialization Functions * * * * * * * * * * * * //

template<class T>
void Foam::Heap<T>::setHeight
()
{
    heapHeight_ = heapHeight();
}


template<class T>
void Foam::Heap<T>::fillKeyedHeap
(
    const List<T>&   heapData,
    const labelList& dataKeys
)
{
    if (dataKeys.size() != heapData.size())
    {
        FatalErrorIn("Heap::fillKeyedHeap()")
            << "nKeys " << dataKeys.size() << " != nDatum " << heapData.size()
            << exit(FatalError);
    }

    DynamicList<HeapNode<T> >& heap_(heap());

    heap_.clear();

    forAll(dataKeys, NID)
    {
        const label keyNID(dataKeys[NID]);
        hardAccessPass(keyNID, "fillKeyedHeap");
        const HeapNode<T> node(NID, heapData[keyNID]);
        heap_.append(node);
    }
}



template<class T>
void Foam::Heap<T>::fillHeap
(
    const List<T>& heapData
)
{
    DynamicList<HeapNode<T> >& heap_(heap());

    heap_.clear();

    forAll(heapData, NID)
    {
        const HeapNode<T> node(NID, heapData[NID]);
        heap_.append(node);
    }
}

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

template<class T>
Foam::Heap<T>::Heap
(
    const label initSize,
    const label heapType
)
:
    DynamicList<HeapNode<T> > (initSize),

    movedNIDs_ (ROOTNID),

    heapHeight_ (ROOTNID),

    nodesWereMoved_ (ROOTNID),

    minHeap_  (heapType == MINHEAP),
    tracking_ (false)

{
    setHeight();
}



template<class T>
Foam::Heap<T>::Heap
(
    const List<T>& initHeapData,
    const label    heapType
)
:
    DynamicList<HeapNode<T> > (initHeapData.size()),

    movedNIDs_ (ROOTNID),

    heapHeight_ (ROOTNID),

    nodesWereMoved_ (ROOTNID),

    minHeap_  (heapType == MINHEAP),
    tracking_ (false)

{
    fillHeap(initHeapData);
    heapSortAllNodes();
    setHeight();
}



template<class T>
Foam::Heap<T>::Heap
(
    const List<T>&   initHeapData,
    const labelList& dataKeys,
    const label      heapType
)
:
    DynamicList<HeapNode<T> > (ROOTNID),

    movedNIDs_ (ROOTNID),

    heapHeight_ (ROOTNID),

    nodesWereMoved_ (ROOTNID),

    minHeap_  (heapType == MINHEAP),
    tracking_ (false)

{
    fillKeyedHeap(initHeapData, dataKeys);
    heapSortAllNodes();
    setHeight();
}


template<class T>
Foam::Heap<T>::Heap
(
    const dictionary& heapDict,
    const label       heapType
)
:
    DynamicList<HeapNode<T> > (ROOTNID),

    movedNIDs_ (ROOTNID),

    heapHeight_ (ROOTNID),

    nodesWereMoved_ (ROOTNID),

    minHeap_  (heapType == MINHEAP),
    tracking_ (false)

{
    const List<T> initHeapData(heapDict.lookup("heapData"));

    if (heapDict.found("dataKeys"))
    {
        const labelList dataKeys(heapDict.lookup("dataKeys"));
        fillKeyedHeap(initHeapData, dataKeys);
    }
    else {fillHeap(initHeapData);}

    heapSortAllNodes();
    setHeight();
}

// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

template<class T>
Foam::Heap<T>::~Heap
()
{}

// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

// * * * * * * * * * * * * * * * Alteration Functions * * * * * * * * * * * * * * //

template<class T>
void Foam::Heap<T>::orderHeap
()
{
    // Order is found by removing root till empty.
    List<T>     orderedHeapData(size());
    const label heapSize(size());

    for (label NID=ROOTNID; NID<heapSize; NID++)
    {orderedHeapData[NID] = takeRootNodeDatum();}

    // Set heap_ as the ordered data.
    reset(orderedHeapData, true);
}



template<class T>
void Foam::Heap<T>::addNode
(
    const T&   newNodeDatum,
    const bool track
)
{
    const label       newNID(size());
    const HeapNode<T> newNode(newNID, newNodeDatum);

    heap().append(newNode);

    if (track) {openTracking();}

    flipNodeCloserToRoot(newNID);

    if (track) {closeTracking();}
}



template<class T>
void Foam::Heap<T>::deleteNode
(
    const label NID,
    const bool  track
)
{
    // Exchange the root node with the last leaf node and delete it.
    // Ensure Heap relations are still valid by re-placing the new root.
    hardAccessPass(NID, "deleteNode");
    Swap(heap()[NID], heap()[size()-1]);
    heap().setSize(size()-1);

    if (track) {openTracking();}
    if (empty())
    {
        if (track) {closeTracking();}
        return;
    }
    if (track) {trackMovedNode(ROOTNID);}

    flipNodeAwayFromRoot(NID);

    if (track) {closeTracking();}
}



template<class T>
void Foam::Heap<T>::deleteRootNode
(
    const bool track
)
{
    deleteNode(ROOTNID, track);
}



template<class T>
void Foam::Heap<T>::rePositionNode
(
    const label NID,
    const bool  track
)
{
    hardAccessPass(NID, "rePositionNode");

    if (track) {openTracking();}

    flipNodeCloserToRoot(NID);
    flipNodeAwayFromRoot(NID);

    if (track) {closeTracking();}
}



template<class T>
T Foam::Heap<T>::takeNodeDatum
(
    const label NID,
    const bool  track
)
{
    // Exchange the root node with the last leaf node and take it.
    // Ensure Heap relations are still valid by re-placing the new root.
    hardAccessPass(NID, "takeNodeDatum");
    Swap(heap()[NID], heap()[size()-1]);

    const T rootNodeDatum(heap().remove().datum);

    if (track) {openTracking();}
    if (empty())
    {
        if (track) {closeTracking();}
        return rootNodeDatum;
    }
    if (track) {trackMovedNode(ROOTNID);}

    flipNodeAwayFromRoot(NID);

    if (track) {closeTracking();}

    return rootNodeDatum;
}



template<class T>
T Foam::Heap<T>::takeRootNodeDatum
(
    const bool track
)
{
    return takeNodeDatum(ROOTNID, track);
}

// * * * * * * * * * * * * * *  Global Functions * * * * * * * * * * * * * * //

template<class T>
void Foam::Heap<T>::reset
(
    const List<T> newHeapData,
    const bool    alreadySorted
)
{
    fillHeap(newHeapData);

    if (!alreadySorted)
    {heapSortAllNodes();}
}



template<class T>
void Foam::Heap<T>::reset
(
    const List<T>    newHeapData,
    const labelList& dataKeys
)
{
    fillKeyedHeap(newHeapData, dataKeys);
    heapSortAllNodes();
}



template<class T>
void Foam::Heap<T>::clear
()
{
    heap().clear();
}

// * * * * * * * * * * * * * * * Print Functions * * * * * * * * * * * * * * //

template<class T>
void Foam::Heap<T>::print
() const
{
    printType();

    Info << "Heap data:";

    const List<HeapNode<T> >& heap_(heap());
    label                     currDepth(ROOTNID);

    forAll(heap_, NID)
    {
        const label depth(nodeDepth(NID));

        if (depth > currDepth)
        {
            currDepth = depth;
            Info << endl;
        }

        Info << "\n\tDepth " << depth << " Node " << NID
             << " Parent " << getParentNID(NID) << ": " << heap_[NID].datum();
    }

    Info << endl;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
