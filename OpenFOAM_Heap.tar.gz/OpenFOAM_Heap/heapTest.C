/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2005 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Application

Description

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"

#include "Heap.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    // Mapped heap test.

    // ---------------------------------------------------------------------//

    // Set initial data to be heaped.
    List<scalar> mSData(15);

    mSData[0] = 0.9;
    mSData[1] = 5.03;
    mSData[2] = 2.43;
    mSData[3] = 322.1;
    mSData[4] = 0.034;
    mSData[5] = 0.71;
    mSData[6] = 0.00034;
    mSData[7] = 5.03;
    mSData[8] = 5.04;
    mSData[9] = 125.4;
    mSData[10] = 46.9982;
    mSData[11] = 12.32;
    mSData[12] = 5.03;
    mSData[13] = 89.2;
    mSData[14] = 2.03;

    const label                 nData(mSData.size());
    List<scalarMappedHeapDatum> mHSData(nData);

    forAll(mSData, datumI)
    {
        const scalarMappedHeapDatum newDatum(mSData[datumI], datumI);
        mHSData[datumI] = newDatum;
    }

    // ---------------------------------------------------------------------//

    // Heap the data in either a min or max Heap.
    const label                 heapType(MINHEAP);
    //const label                 heapType(MINHEAP);
    Heap<scalarMappedHeapDatum> mappedScalarHeap(mHSData, heapType);

    // Get the initial maps to the heap.
    labelList mHSMapToHeap(nData);

    forAll(mappedScalarHeap.rtnHeap(), NID)
    {mHSMapToHeap[mappedScalarHeap.peekNodeDatum(NID).mapID] = NID;}

    // Print the initial info.
    Info << "Initial mapped Heap:"
         << endl;

    mappedScalarHeap.print();

    Info << "Initial map to Heap: " << mHSMapToHeap
         << endl;

    // ---------------------------------------------------------------------//

    // Repeatedly take the best (i.e. root) datum and maintain mapping.
    scalarList sortedHeap(nData);
    const bool track(true);

    for (label datumI=0; datumI<nData; datumI++)
    {
        // Take the best datum from each heap and get the NIDs which were
        // affected by the subsequent reshuffling.
        const scalarMappedHeapDatum rootDatum
                                    (mappedScalarHeap.takeRootNodeDatum(track));
        const labelList&            movedNIDs(mappedScalarHeap.rtnMovedNIDs());

        Info << "------------------------------------------"
             << "\nTaken root datum " << rootDatum()
             << "\nmovedNIDs " << movedNIDs
             << endl;

        // -----------------------------------------------------------------//

        // Maintain the mapping onto the Heap.
        mHSMapToHeap[rootDatum.mapID] = -1;
        sortedHeap[datumI]            = rootDatum.value;

        forAll(movedNIDs, movedI)
        {
            const label& NID(movedNIDs[movedI]);
            mHSMapToHeap[mappedScalarHeap.peekNodeDatum(NID).mapID] = NID;
        }

        // -----------------------------------------------------------------//

        // Print the current heaps and mappings.
        Info << "current mapped Heap:"
             << endl;

        mappedScalarHeap.print();

        Info << "current map to Heap: " << mHSMapToHeap
             << endl;
    }

    // ---------------------------------------------------------------------//

    Info << "------------------------------------------"
         << "\n\nfound sortedHeap: " << sortedHeap
         << endl;
}

// ************************************************************************* //
